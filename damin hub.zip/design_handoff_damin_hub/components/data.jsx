// Mock data — 50 links across work + personal

const WORK_CATEGORIES = [
  { id: 'w-ops',    name: '운영/어드민',   color: '#1F2B4D', count: 8 },
  { id: 'w-design', name: '디자인/리서치', color: '#7A2E2B', count: 7 },
  { id: 'w-dev',    name: '개발 도구',     color: '#1A1D24', count: 9 },
  { id: 'w-docs',   name: '문서/위키',     color: '#2B3A63', count: 6 },
  { id: 'w-data',   name: '데이터/분석',   color: '#A94D49', count: 5 },
];

const PERSONAL_CATEGORIES = [
  { id: 'p-read',   name: '읽을거리',    color: '#1F2B4D', count: 6 },
  { id: 'p-ref',    name: '레퍼런스',    color: '#7A2E2B', count: 5 },
  { id: 'p-learn',  name: '학습/강의',   color: '#2B3A63', count: 4 },
  { id: 'p-life',   name: '일상/쇼핑',   color: '#1A1D24', count: 4 },
  { id: 'p-inspo',  name: '영감/포트폴', color: '#A94D49', count: 3 },
];

const palette = [
  ['#F2EEEE', '#7A2E2B'],   // mahogany on cream
  ['#E8ECF2', '#1F2B4D'],   // navy on silver-blue
  ['#1F2B4D', '#E8ECF2'],   // inverse navy
  ['#EEF0F2', '#1A1D24'],   // ink on silver
  ['#7A2E2B', '#F2EEEE'],   // inverse mahogany
  ['#DCE0E6', '#2B3A63'],   // navy-2 on silver-2
  ['#1A1D24', '#C5C8CC'],   // silver on ink
];
const iconFor = i => ({ iconBg: palette[i % palette.length][0], iconFg: palette[i % palette.length][1] });

function cat(catList, id) {
  const c = catList.find(x => x.id === id);
  return { categoryName: c.name, categoryColor: c.color };
}

const WORK_LINKS_RAW = [
  // ops
  ['Notion · 팀 워크스페이스', 'notion.so/damin/team', 'w-ops', ['주간회의','공유'], 142, '오늘 09:12', true],
  ['Slack · #product-dev', 'app.slack.com/client/T01/C02', 'w-ops', ['자주'], 98, '오늘 09:45', true],
  ['Google Calendar', 'calendar.google.com/u/0/r/week', 'w-ops', ['자주'], 74, '오늘 08:30', true],
  ['Zoom 회의실', 'zoom.us/j/damin-standup', 'w-ops', ['주간회의'], 41, '어제', false],
  ['1Password · Team', '1password.com/vaults/team', 'w-ops', ['긴급'], 22, '3일 전', false],
  ['OKR 트래커', 'notion.so/damin/okr-2026-q2', 'w-ops', ['주간회의'], 18, '어제', false],
  ['HR · 연차신청', 'hr.damin.co/leaves', 'w-ops', [], 8, '2주 전', false],
  ['비용 청구', 'expense.damin.co', 'w-ops', [], 6, '지난달', false],

  // design
  ['Figma · Design System', 'figma.com/file/DAMIN-DS/v4', 'w-design', ['레퍼런스','자주'], 89, '오늘 10:22', true],
  ['Figma · Q2 Roadmap', 'figma.com/file/Q2-roadmap', 'w-design', ['주간회의'], 54, '오늘 09:58', false],
  ['Dovetail · User Interviews', 'dovetailapp.com/projects/42', 'w-design', ['참고'], 31, '어제', false],
  ['Maze · Usability', 'app.maze.co/p/damin', 'w-design', ['참고'], 19, '3일 전', false],
  ['Storybook · Components', 'storybook.damin.co', 'w-design', ['레퍼런스','자주'], 67, '오늘 11:04', true],
  ['Design Review (Loom)', 'loom.com/damin/review', 'w-design', ['주간회의'], 12, '어제', false],
  ['Icon Library', 'icons.damin.co', 'w-design', ['레퍼런스'], 28, '5일 전', false],

  // dev
  ['GitHub · damin/monorepo', 'github.com/damin/monorepo', 'w-dev', ['자주'], 186, '오늘 11:40', true],
  ['Linear · My Issues', 'linear.app/damin/my-issues', 'w-dev', ['긴급','자주'], 203, '오늘 11:52', true],
  ['Vercel · Production', 'vercel.com/damin/app', 'w-dev', ['자주'], 92, '오늘 10:11', false],
  ['Sentry · Errors', 'sentry.io/damin/prod', 'w-dev', ['긴급'], 44, '오늘 08:50', false],
  ['CI/CD Dashboard', 'ci.damin.co', 'w-dev', [], 38, '어제', false],
  ['Database Console', 'db.damin.co/query', 'w-dev', ['자주'], 51, '오늘 10:30', false],
  ['API Playground', 'api.damin.co/playground', 'w-dev', ['레퍼런스'], 29, '2일 전', false],
  ['Staging Env', 'staging.damin.co', 'w-dev', ['임시'], 35, '어제', false],
  ['Feature Flags', 'flags.damin.co', 'w-dev', [], 16, '4일 전', false],

  // docs
  ['Confluence · Eng Wiki', 'damin.atlassian.net/wiki/eng', 'w-docs', ['레퍼런스'], 47, '어제', false],
  ['Product Spec · Auth v2', 'notion.so/damin/auth-v2-spec', 'w-docs', ['주간회의','참고'], 31, '오늘 09:20', false],
  ['ADR · Architecture Decisions', 'notion.so/damin/adr', 'w-docs', ['레퍼런스'], 23, '3일 전', false],
  ['온보딩 핸드북', 'notion.so/damin/handbook', 'w-docs', [], 11, '2주 전', false],
  ['릴리즈 노트', 'notion.so/damin/releases', 'w-docs', ['공유'], 19, '어제', false],
  ['Brand Guidelines', 'brand.damin.co', 'w-docs', ['레퍼런스'], 14, '1주 전', false],

  // data
  ['Amplitude · Product', 'analytics.amplitude.com/damin', 'w-data', ['자주'], 62, '오늘 11:15', true],
  ['Metabase · Exec Dash', 'metabase.damin.co/dashboard/1', 'w-data', ['주간회의'], 48, '오늘 10:05', false],
  ['Mixpanel · Funnels', 'mixpanel.com/project/damin', 'w-data', ['참고'], 27, '어제', false],
  ['BigQuery Console', 'console.cloud.google.com/bigquery', 'w-data', [], 21, '3일 전', false],
  ['Looker Studio', 'lookerstudio.google.com/damin', 'w-data', ['공유'], 15, '5일 전', false],
];

const PERSONAL_LINKS_RAW = [
  ['Hacker News', 'news.ycombinator.com', 'p-read', ['자주'], 88, '오늘 07:30', true],
  ['The Verge', 'theverge.com', 'p-read', [], 34, '어제', false],
  ['Stratechery', 'stratechery.com', 'p-read', ['참고'], 22, '3일 전', false],
  ['Pocket · 읽을거리', 'getpocket.com/my-list', 'p-read', ['자주'], 41, '오늘 08:12', false],
  ['Medium · Following', 'medium.com/me/following', 'p-read', [], 18, '어제', false],
  ['Substack · Inbox', 'substack.com/inbox', 'p-read', [], 26, '2일 전', false],

  ['CSS-Tricks', 'css-tricks.com', 'p-ref', ['레퍼런스','자주'], 52, '오늘 11:00', true],
  ['MDN Web Docs', 'developer.mozilla.org', 'p-ref', ['레퍼런스'], 71, '오늘 10:40', true],
  ['Smashing Magazine', 'smashingmagazine.com', 'p-ref', ['레퍼런스'], 29, '어제', false],
  ['Interaction Design Foundation', 'interaction-design.org', 'p-ref', [], 12, '1주 전', false],
  ['Refactoring UI', 'refactoringui.com', 'p-ref', ['레퍼런스'], 17, '3일 전', false],

  ['YouTube · Watch Later', 'youtube.com/playlist?list=WL', 'p-learn', ['자주'], 44, '오늘 09:00', false],
  ['Coursera · Progress', 'coursera.org/learn/design', 'p-learn', [], 11, '1주 전', false],
  ['GitHub · starred', 'github.com/damin?tab=stars', 'p-learn', ['레퍼런스'], 33, '어제', true],
  ['Frontend Masters', 'frontendmasters.com/learn', 'p-learn', [], 9, '2주 전', false],

  ['Kurly · 장보기', 'kurly.com', 'p-life', ['자주'], 28, '오늘 07:15', false],
  ['Toss · 가계부', 'toss.im/my', 'p-life', ['자주'], 56, '오늘 08:00', true],
  ['날씨 · 서울', 'weather.naver.com/today/09110101', 'p-life', [], 21, '오늘 07:50', false],
  ['Spotify · Discover', 'open.spotify.com/genre/made-for-you', 'p-life', [], 19, '어제', false],

  ['Dribbble · Inspiration', 'dribbble.com/shots/popular', 'p-inspo', ['레퍼런스'], 37, '어제', false],
  ['Behance · Curated', 'behance.net/galleries', 'p-inspo', [], 15, '3일 전', false],
  ['Awwwards', 'awwwards.com', 'p-inspo', ['레퍼런스'], 22, '2일 전', false],
];

function buildLinks(raw, catList, prefix) {
  return raw.map((r, i) => {
    const [title, displayUrl, catId, tags, visits, lastVisit, pinned] = r;
    const c = cat(catList, catId);
    return {
      id: `${prefix}-${i}`,
      title,
      displayUrl,
      url: 'https://' + displayUrl,
      categoryId: catId,
      categoryName: c.categoryName,
      categoryColor: c.categoryColor,
      tags,
      visits,
      lastVisit,
      pinned,
      ...iconFor(i + (prefix === 'p' ? 3 : 0)),
    };
  });
}

const WORK_LINKS = buildLinks(WORK_LINKS_RAW, WORK_CATEGORIES, 'w');
const PERSONAL_LINKS = buildLinks(PERSONAL_LINKS_RAW, PERSONAL_CATEGORIES, 'p');

Object.assign(window, { WORK_CATEGORIES, PERSONAL_CATEGORIES, WORK_LINKS, PERSONAL_LINKS });
