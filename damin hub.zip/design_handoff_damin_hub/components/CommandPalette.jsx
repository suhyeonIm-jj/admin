const { useEffect: useEffectCP, useRef: useRefCP, useState: useStateCP } = React;

function CommandPalette({ open, onClose, links, categories }) {
  const [q, setQ] = useStateCP('');
  const inputRef = useRefCP(null);

  useEffectCP(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current.focus(), 40);
    }
    if (!open) setQ('');
  }, [open]);

  if (!open) return null;

  const filtered = q
    ? links.filter(l =>
        l.title.toLowerCase().includes(q.toLowerCase()) ||
        l.displayUrl.toLowerCase().includes(q.toLowerCase()) ||
        l.tags.some(t => t.includes(q))
      ).slice(0, 8)
    : links.filter(l => l.pinned).slice(0, 6);

  return (
    <div className="cmd-overlay" onClick={onClose}>
      <div className="cmd-modal" onClick={e => e.stopPropagation()}>
        <div className="cmd-input-wrap">
          <svg width="15" height="15" viewBox="0 0 15 15" fill="none"><circle cx="6.5" cy="6.5" r="4.5" stroke="currentColor" strokeWidth="1.3"/><path d="M10 10l3.5 3.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>
          <input
            ref={inputRef}
            value={q}
            onChange={e => setQ(e.target.value)}
            placeholder="링크 제목, URL, #태그로 검색..."
          />
          <kbd className="cmd-kbd">ESC</kbd>
        </div>

        <div className="cmd-section-label">
          {q ? `검색 결과 · ${filtered.length}` : '고정된 링크'}
        </div>

        <div className="cmd-list">
          {filtered.map((l, i) => (
            <a key={l.id} href={l.url} className={`cmd-item ${i === 0 ? 'hl' : ''}`} target="_blank" rel="noreferrer">
              <Favicon link={l} />
              <div className="cmd-item-main">
                <div className="cmd-item-title">{l.title}</div>
                <div className="cmd-item-url">{l.displayUrl}</div>
              </div>
              <div className="cmd-item-meta">
                <span className="cat-dot" style={{ background: l.categoryColor }}></span>
                <span>{l.categoryName}</span>
              </div>
              <kbd className="cmd-kbd">↵</kbd>
            </a>
          ))}
          {filtered.length === 0 && (
            <div className="cmd-empty">일치하는 결과가 없어요</div>
          )}
        </div>

        <div className="cmd-footer">
          <div className="cmd-hint">
            <kbd>↑</kbd><kbd>↓</kbd> 이동
          </div>
          <div className="cmd-hint">
            <kbd>↵</kbd> 열기
          </div>
          <div className="cmd-hint">
            <kbd>⌘</kbd><kbd>↵</kbd> 새 탭
          </div>
          <div className="cmd-hint right">
            <span className="dot-live"></span> 실시간 검색
          </div>
        </div>
      </div>
    </div>
  );
}

function AddLinkModal({ open, onClose, categories }) {
  if (!open) return null;
  return (
    <div className="cmd-overlay" onClick={onClose}>
      <div className="add-modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <div className="modal-title">새 링크 추가</div>
            <div className="modal-sub">URL을 붙여넣으면 제목과 파비콘이 자동으로 채워져요</div>
          </div>
          <button className="icon-btn" onClick={onClose}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>
          </button>
        </div>
        <div className="form-field">
          <label>URL</label>
          <input className="input" placeholder="https://..." defaultValue="https://linear.app/damin/my-issues" />
        </div>
        <div className="form-row">
          <div className="form-field">
            <label>제목</label>
            <input className="input" defaultValue="My Issues – Linear" />
          </div>
          <div className="form-field">
            <label>카테고리</label>
            <select className="input">
              {categories.map(c => <option key={c.id}>{c.name}</option>)}
            </select>
          </div>
        </div>
        <div className="form-field">
          <label>태그</label>
          <div className="tag-input">
            <span className="tag-chip sm">#긴급</span>
            <span className="tag-chip sm">#주간회의</span>
            <input className="tag-inner" placeholder="태그 추가..." />
          </div>
        </div>
        <div className="form-field">
          <label>메모 (선택)</label>
          <textarea className="input" rows="2" placeholder="이 링크에 대한 설명이나 메모"></textarea>
        </div>
        <div className="form-field row-field">
          <label className="checkbox">
            <input type="checkbox" defaultChecked />
            <span>사이드바에 고정</span>
          </label>
          <label className="checkbox">
            <input type="checkbox" />
            <span>새 탭으로 열기</span>
          </label>
        </div>
        <div className="modal-foot">
          <button className="btn-ghost" onClick={onClose}>취소</button>
          <button className="btn-primary">저장</button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { CommandPalette, AddLinkModal });
