const { useState } = React;

function Sidebar({ workspace, setWorkspace, activeCategory, setActiveCategory, categories, counts }) {
  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="logo">
          <div className="logo-mark">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <rect x="2" y="2" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.9"/>
              <rect x="10" y="2" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.5"/>
              <rect x="2" y="10" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.5"/>
              <rect x="10" y="10" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.9"/>
            </svg>
          </div>
          <div className="logo-text">
            <div className="logo-title">Damin Hub</div>
            <div className="logo-sub">admin workspace</div>
          </div>
        </div>
      </div>

      <div className="workspace-switch">
        <button
          className={`ws-btn ${workspace === 'work' ? 'active' : ''}`}
          onClick={() => setWorkspace('work')}
        >
          <span className="ws-dot work"></span>
          업무
          <span className="ws-count">{counts.work}</span>
        </button>
        <button
          className={`ws-btn ${workspace === 'personal' ? 'active' : ''}`}
          onClick={() => setWorkspace('personal')}
        >
          <span className="ws-dot personal"></span>
          개인
          <span className="ws-count">{counts.personal}</span>
        </button>
      </div>

      <nav className="nav">
        <div className="nav-section">
          <div className="nav-label">둘러보기</div>
          <button
            className={`nav-item ${activeCategory === 'all' ? 'active' : ''}`}
            onClick={() => setActiveCategory('all')}
          >
            <IconGrid />
            <span>전체</span>
            <span className="nav-count">{counts.total}</span>
          </button>
          <button
            className={`nav-item ${activeCategory === 'pinned' ? 'active' : ''}`}
            onClick={() => setActiveCategory('pinned')}
          >
            <IconStar />
            <span>즐겨찾기</span>
            <span className="nav-count">{counts.pinned}</span>
          </button>
          <button
            className={`nav-item ${activeCategory === 'recent' ? 'active' : ''}`}
            onClick={() => setActiveCategory('recent')}
          >
            <IconClock />
            <span>최근 방문</span>
            <span className="nav-count">{counts.recent}</span>
          </button>
        </div>

        <div className="nav-section">
          <div className="nav-label">카테고리</div>
          {categories.map(cat => (
            <button
              key={cat.id}
              className={`nav-item ${activeCategory === cat.id ? 'active' : ''}`}
              onClick={() => setActiveCategory(cat.id)}
            >
              <span className="cat-dot" style={{ background: cat.color }}></span>
              <span>{cat.name}</span>
              <span className="nav-count">{cat.count}</span>
            </button>
          ))}
          <button className="nav-item add-cat">
            <IconPlus />
            <span>카테고리 추가</span>
          </button>
        </div>

        <div className="nav-section">
          <div className="nav-label">태그</div>
          <div className="tag-cloud">
            {['긴급', '주간회의', '참고', '레퍼런스', '자주', '임시', '공유'].map(t => (
              <span key={t} className="tag-chip">#{t}</span>
            ))}
          </div>
        </div>
      </nav>

      <div className="sidebar-footer">
        <div className="user-card">
          <div className="avatar">DM</div>
          <div className="user-info">
            <div className="user-name">Damin</div>
            <div className="user-email">admin@damin.hub</div>
          </div>
          <button className="icon-btn" title="설정">
            <IconSettings />
          </button>
        </div>
      </div>
    </aside>
  );
}

function IconGrid() {
  return <svg width="15" height="15" viewBox="0 0 15 15" fill="none"><rect x="2" y="2" width="4.5" height="4.5" rx="1" stroke="currentColor" strokeWidth="1.3"/><rect x="8.5" y="2" width="4.5" height="4.5" rx="1" stroke="currentColor" strokeWidth="1.3"/><rect x="2" y="8.5" width="4.5" height="4.5" rx="1" stroke="currentColor" strokeWidth="1.3"/><rect x="8.5" y="8.5" width="4.5" height="4.5" rx="1" stroke="currentColor" strokeWidth="1.3"/></svg>;
}
function IconStar() {
  return <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round"><path d="M7 1.5l1.7 3.55 3.9.48-2.88 2.68.74 3.85L7 10.24 3.54 12.06l.74-3.85L1.4 5.53l3.9-.48L7 1.5z"/></svg>;
}
function IconPin() {
  return <svg width="15" height="15" viewBox="0 0 15 15" fill="none"><path d="M7.5 1.5v5M4 6.5h7l-1 3H5l-1-3zM7.5 9.5v4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>;
}
function IconClock() {
  return <svg width="15" height="15" viewBox="0 0 15 15" fill="none"><circle cx="7.5" cy="7.5" r="5.5" stroke="currentColor" strokeWidth="1.3"/><path d="M7.5 4.5v3l2 1.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>;
}
function IconPlus() {
  return <svg width="15" height="15" viewBox="0 0 15 15" fill="none"><path d="M7.5 3v9M3 7.5h9" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>;
}
function IconSettings() {
  return <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="2" stroke="currentColor" strokeWidth="1.2"/><path d="M7 1v1.5M7 11.5V13M1 7h1.5M11.5 7H13M2.5 2.5l1 1M10.5 10.5l1 1M2.5 11.5l1-1M10.5 3.5l1-1" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/></svg>;
}

Object.assign(window, { Sidebar });
