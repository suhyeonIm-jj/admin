function Favicon({ link }) {
  return (
    <div className="favicon" style={{ background: link.iconBg, color: link.iconFg }}>
      <span className="favicon-letter">{link.title.charAt(0)}</span>
    </div>
  );
}

function StarIcon({ filled }) {
  return (
    <svg width="13" height="13" viewBox="0 0 14 14" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round">
      <path d="M7 1.5l1.7 3.55 3.9.48-2.88 2.68.74 3.85L7 10.24 3.54 12.06l.74-3.85L1.4 5.53l3.9-.48L7 1.5z"/>
    </svg>
  );
}

function LinkCard({ link, onTogglePin }) {
  return (
    <a href={link.url} className="link-card" target="_blank" rel="noreferrer">
      <div className="card-top">
        <Favicon link={link} />
        <button
          className={`pin-btn ${link.pinned ? 'pinned' : ''}`}
          onClick={e => { e.preventDefault(); onTogglePin(link.id); }}
          title={link.pinned ? '즐겨찾기 해제' : '즐겨찾기'}
          aria-label={link.pinned ? '즐겨찾기 해제' : '즐겨찾기 추가'}
        >
          <StarIcon filled={link.pinned} />
        </button>
      </div>
      <div className="card-body">
        <div className="card-title">{link.title}</div>
        <div className="card-url">{link.displayUrl}</div>
      </div>
      <div className="card-foot">
        <div className="tags">
          {link.tags.slice(0, 2).map(t => (
            <span key={t} className="tag-chip sm">#{t}</span>
          ))}
        </div>
        <div className="card-cat">
          <span className="cat-dot" style={{ background: link.categoryColor }}></span>
          <span className="cat-name">{link.categoryName}</span>
        </div>
      </div>
    </a>
  );
}

function LinkRow({ link, onTogglePin }) {
  return (
    <a href={link.url} className="link-row" target="_blank" rel="noreferrer">
      <button
        className={`pin-btn inline ${link.pinned ? 'pinned' : ''}`}
        onClick={e => { e.preventDefault(); onTogglePin(link.id); }}
      >
        <StarIcon filled={link.pinned} />
      </button>
      <Favicon link={link} />
      <div className="row-main">
        <div className="row-title">{link.title}</div>
        <div className="row-url">{link.displayUrl}</div>
      </div>
      <div className="row-tags">
        {link.tags.slice(0, 3).map(t => (
          <span key={t} className="tag-chip sm">#{t}</span>
        ))}
      </div>
      <div className="row-category">
        <span className="cat-dot" style={{ background: link.categoryColor }}></span>
        {link.categoryName}
      </div>
      <div className="row-actions">
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M5 3l4 4-4 4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>
      </div>
    </a>
  );
}

function LinkCompact({ link, onTogglePin }) {
  return (
    <a href={link.url} className="link-compact" target="_blank" rel="noreferrer">
      <Favicon link={link} />
      <div className="compact-title">{link.title}</div>
      <div className="compact-url">{link.displayUrl}</div>
    </a>
  );
}

Object.assign(window, { LinkCard, LinkRow, LinkCompact, Favicon, StarIcon });
