# Handoff: Damin Hub · Admin

## Overview
개인 + 업무용 북마크 허브 어드민 사이트입니다. 사용자는 자주 이동하는 업무 링크와 개인 북마크를 **하나의 워크스페이스**에서 카테고리/태그별로 정리하고, 검색하고, 즐겨찾기로 핀 고정하여 빠르게 접근합니다.

주요 화면:
- 업무 링크 허브 (기본 워크스페이스)
- 개인 북마크 (워크스페이스 전환)
- 카테고리별 필터 뷰
- 즐겨찾기 뷰 / 최근 방문 뷰
- 커맨드 팔레트 (⌘K) — 검색
- 링크 추가 모달

## About the Design Files
이 번들에 포함된 HTML/JSX/CSS 파일들은 **디자인 참조용 프로토타입**입니다. 최종 룩앤필과 동작 의도를 보여주는 하이-피델리티 목업이지, 프로덕션에 그대로 복사할 코드가 아닙니다.

개발자의 역할은 **대상 코드베이스의 기존 환경(React/Vue/Next.js 등)과 디자인 시스템 위에서 이 디자인을 재구현**하는 것입니다. 기존 컴포넌트 라이브러리(shadcn/ui, Radix, Chakra 등)가 있다면 그것을 우선 사용하세요. 새 프로젝트라면 React + Tailwind(또는 CSS Modules) 조합을 권장합니다.

## Fidelity
**High-fidelity (hifi).** 색상, 타이포그래피, 간격, 인터랙션, 마이크로 애니메이션까지 최종안에 가깝게 설계되어 있습니다. 픽셀 단위로 재현하는 것을 목표로 하되, 대상 코드베이스의 토큰/유틸리티가 있다면 그에 맞춰 매핑하세요.

## Design Tokens

### Colors (Light theme — default)
```
/* Brand palette: black, mahogany, silver, navy */
--c-black:        #0E0E10
--c-ink:          #1A1D24    /* navy-tinted black, 본문 텍스트 */
--c-navy:         #1F2B4D    /* 딥 네이비, work 액센트 */
--c-navy-2:       #2B3A63
--c-mahogany:     #7A2E2B    /* 마호가니, personal 액센트 */
--c-mahogany-2:   #A94D49
--c-silver:       #C5C8CC
--c-silver-2:     #E3E5E8
--c-silver-3:     #EEF0F2

/* Surfaces */
--bg:         #FBFAF7      /* 메인 콘텐츠 배경 (웜 화이트) */
--bg-elev:    #FFFFFF      /* 카드, 모달 */
--bg-sunken:  #E1DED2      /* 사이드바 (실버 베이지) */
--bg-hover:   #D6D2C2
--bg-active:  #C9C4B1

/* Borders */
--border:        #E1E2E4
--border-strong: #C5C8CC

/* Text */
--fg:        #1A1D24
--fg-muted:  #50555E
--fg-subtle: #7C8089
--fg-faint:  #A8ACB3

/* Accent (navy 기반) */
--accent:        #1F2B4D
--accent-fg:     #FFFFFF
--accent-soft:   #E6EAF2
--accent-border: #B7C1D6

/* Favorite star */
--favorite: #E8B73A    /* 선택된 즐겨찾기 상태에서만 노출 */
```

### Colors (Dark theme)
```
--bg:         #14161B
--bg-elev:    #1C1F26
--bg-sunken:  #08090C
--bg-hover:   #232631
--bg-active:  #2C3040

--border:        #262932
--border-strong: #3A3E48

--fg:        #ECEDEF
--fg-muted:  #A8ACB3
--fg-subtle: #7C8089
--fg-faint:  #555861

--accent:        #6B87C2
--accent-soft:   #1E2A46
--accent-border: #3A4A6F

--favorite: #F5CB58
```

### Typography
- **Sans (본문):** Inter — weights 400, 500, 600, 700
- **Mono (메타/숫자/단축키):** JetBrains Mono — weights 400, 500
- 둘 다 Google Fonts
- `letter-spacing: -0.005em` 기본, 타이틀은 `-0.01em ~ -0.02em`

### Scale
| 용도 | size / weight / line-height |
|---|---|
| Page title (h1) | 22px / 600 / 1.2 / `-0.02em` |
| Page subtitle | 13px / 400 / 1.5 / muted |
| Section title | 13px / 600 |
| Card title | 13px / 500 |
| Body default | 14px / 400 / 1.5 |
| URL, count, kbd | mono 10–11px |
| Section label (uppercase) | mono 10–11px / `letter-spacing: 0.06–0.08em` |

### Spacing / Radius / Shadow
```
--radius-xs: 4px
--radius-sm: 6px
--radius-md: 8px    /* 카드, 버튼 */
--radius-lg: 12px   /* 모달, 팔레트 */
--radius-xl: 16px

--shadow-sm: 0 1px 2px rgba(15,20,35,.04)
--shadow-md: 0 4px 16px -4px rgba(15,20,35,.08), 0 1px 2px rgba(15,20,35,.04)
--shadow-lg: 0 24px 48px -12px rgba(15,20,35,.18), 0 2px 8px rgba(15,20,35,.06)
```

## Layout

### App shell
CSS Grid `260px 1fr` — 좌측 사이드바(고정 폭 260px) + 우측 메인. `height: 100vh`, 사이드바/메인 각각 내부 스크롤.

### Sidebar (260px)
1. **Header**: 로고 마크(28×28 navy 사각형 그리드) + "Damin Hub" / "ADMIN WORKSPACE"
2. **Workspace switch**: 2-segment 토글 — 업무 / 개인 (각각 navy / mahogany 점 표시, 링크 개수 뱃지)
3. **Nav**
   - 둘러보기: 전체 / 즐겨찾기 / 최근 방문 (아이콘 + 라벨 + count)
   - 카테고리: 컬러 닷 + 이름 + count, 하단에 "카테고리 추가" ghost 버튼
   - 태그: 태그 클라우드 (mono 10.5px, chip 스타일)
4. **Footer**: 유저 카드 (아바타 이니셜 gradient + 이름 + 이메일 + 설정 아이콘)

> 핵심: 사이드바는 `--bg-sunken`(#E1DED2), 메인은 `--bg`(#FBFAF7). **확실하게 톤 차이를 주는 것이 중요**.

### Main
1. **Topbar** (padding 22px 32px)
   - 좌측: breadcrumb (mono 11px) → Page title (22px/600) → subtitle (13px muted)
   - 우측: 검색 트리거(min-width 340px, ⌘K 키캡), 뷰 세그먼트(카드/리스트/컴팩트), 정렬 select, 링크 추가 primary 버튼
2. **Content** (padding 20px 32px 48px, overflow-y auto)
   - `전체` 필터일 때: 즐겨찾기 섹션 → 자주 방문 TOP 6 섹션 → 모든 링크 섹션
   - 특정 카테고리/필터일 때: 해당 섹션 하나만
   - 각 섹션 헤더: 타이틀 + count chip (좌) / UPPERCASE action label (우, mono)

### Card grid
`grid-template-columns: repeat(auto-fill, minmax(240px, 1fr))`, gap 10px.

카드 구조 (padding 14px, `bg-elev`, border, radius-md, min-height 112px, hover 시 `translateY(-1px) + shadow-md`):
- 상단: favicon(28×28 라운드 7px, 카테고리 팔레트 기반 bg/fg + 첫 글자) / 우측 별표 버튼
- 본문: 제목 (13px/500, 1줄 ellipsis) + URL (mono 10.5px muted, 1줄 ellipsis)
- 하단: 태그 chips (최대 2개) / 카테고리 닷 + 이름

> **방문 횟수, 최근 방문 시간은 카드에 표시하지 않음.** (데이터는 내부적으로 있지만 UI에는 노출 X)

### Favorite star behavior
- 기본 상태: 카드에서 별표 **숨김** (opacity 0)
- 카드 hover 시: outline 별표가 faint 색으로 페이드 인
- Pinned 상태: **항상 보이며 노란색(`--favorite` #E8B73A)으로 채워진 별표**
- 클릭 시 pinned 토글

## Interactions & Behavior

### Keyboard
- `⌘K` / `Ctrl+K` → 커맨드 팔레트 토글
- `ESC` → 모달 / 팔레트 닫기
- 팔레트 내 힌트: ↑↓ 이동, ↵ 열기, ⌘↵ 새 탭 (구현은 안 된 상태, 힌트만 표시 OK — 실제 구현 시 추가)

### Command palette (⌘K)
- 오버레이: `rgba` black 55% + `backdrop-filter: blur(6px)`
- 모달: 620px, radius-lg, shadow-lg, 검색 input (placeholder "링크 제목, URL, #태그로 검색...") + ESC 키캡
- 빈 상태: pinned 링크 6개 표시 ("고정된 링크" 섹션 라벨)
- 검색어 입력 시: title/URL/tags 부분 일치로 상위 8개 필터
- 각 아이템: favicon + 제목/URL + 카테고리 닷+이름 + ↵ 키캡
- Footer: ↑↓ 이동, ↵ 열기, ⌘↵ 새 탭, 우측 실시간 검색 점(mahogany)

### Add Link modal
540px, padding 22px 24px. URL / 제목 + 카테고리(row) / 태그(chip 입력) / 메모(textarea) / 사이드바 고정·새 탭 체크박스 / 취소·저장 버튼.

### Transitions
- 카드 hover: `transform 0.12s, box-shadow 0.12s`
- 버튼, nav item hover: `background/color 0.1–0.12s`
- 모달/팔레트 등장: `opacity + translateY(-4px)` 0.15–0.2s ease-out
- 애니메이션은 `prefers-reduced-motion` 존중 권장 (현재 프로토타입엔 미구현)

### Theme toggle
- 우하단 고정 pill (30px 원형 버튼 2개)
- `localStorage.theme` 에 저장, `<html data-theme="light|dark">` 으로 CSS 변수 스위치
- Tweaks 패널에서도 전환 가능

## State Management

목데이터 구조 (`components/data.jsx` 참조):

```ts
interface Link {
  id: string;
  title: string;
  displayUrl: string;      // 호스트부터 경로까지 (protocol 제외)
  url: string;             // 실제 href (with https://)
  categoryId: string;
  categoryName: string;
  categoryColor: string;   // hex
  tags: string[];
  visits: number;          // 내부 소팅/검색용, UI 미노출
  lastVisit: string;       // 상대 시간 한국어, 내부 소팅/검색용, UI 미노출
  pinned: boolean;
  iconBg: string;          // favicon bg
  iconFg: string;          // favicon fg
}

interface Category {
  id: string;
  name: string;
  color: string;           // hex
}
```

필요한 앱 상태:
- `theme`: 'light' | 'dark'  — localStorage 동기화
- `workspace`: 'work' | 'personal'  — localStorage 동기화, 변경 시 activeCategory='all'로 리셋
- `activeCategory`: 'all' | 'pinned' | 'recent' | categoryId
- `view`: 'card' | 'list' | 'compact'  — localStorage 동기화
- `sortBy`: 'recent' | 'name' | 'visits' | 'added'
- `pinnedMap`: `{[linkId]: boolean}`  — 런타임 오버라이드
- `cmdOpen`, `addOpen`: 모달 상태
- `query`: 커맨드 팔레트 검색어

실제 구현 시에는 mock 데이터를 API 엔드포인트로 교체하고, pinned/visits 업데이트를 서버에 persist. 추천: 서버 상태는 TanStack Query, 클라 UI 상태는 Zustand 또는 useState.

## Categories (mock)

**Work**: 운영/어드민 (navy), 디자인/리서치 (mahogany), 개발 도구 (ink), 문서/위키 (navy-2), 데이터/분석 (mahogany-2)

**Personal**: 읽을거리, 레퍼런스, 학습/강의, 일상/쇼핑, 영감/포트폴 — 같은 5색 팔레트 재사용

## Assets
- 아이콘: 모두 인라인 SVG (외부 아이콘 라이브러리 의존 없음). 실제 구현 시 lucide-react 등으로 교체 가능 — star / pin / grid / clock / plus / search / settings / chevron-right / sun / moon / close.
- Favicon: 실제 사이트 파비콘이 아니라 **첫 글자 + 팔레트 배경**으로 placeholder 생성. 실 서비스에선 `https://www.google.com/s2/favicons?domain=...` 또는 자체 프록시로 대체.

## Files in this bundle
```
Admin Hub.html                  # 메인 엔트리, React 앱 루트 + 상태 관리
styles.css                      # 전체 디자인 토큰 + 컴포넌트 스타일
components/
  data.jsx                      # 카테고리/링크 목데이터
  Sidebar.jsx                   # 좌측 사이드바 (워크스페이스 전환, 카테고리, 태그)
  Topbar.jsx                    # 상단 브레드크럼+타이틀+검색+뷰 토글+정렬+추가
  LinkCard.jsx                  # LinkCard / LinkRow / LinkCompact / StarIcon / Favicon
  CommandPalette.jsx            # ⌘K 팔레트 + Add Link 모달
```

## 구현 팁

1. **컴포넌트 매핑**: `LinkCard`는 기존 Card 컴포넌트, `CommandPalette`는 cmdk 라이브러리(shadcn/ui에 이미 있음), 모달은 Radix Dialog로 매핑하는 것이 가장 빠릅니다.
2. **테마 토큰**: CSS 변수로 정의되어 있으므로 Tailwind v4의 `@theme` 또는 CSS Modules + `:root[data-theme]` 그대로 포팅 가능합니다.
3. **사이드바 대비**: 사이드바 배경 `#E1DED2`와 메인 `#FBFAF7`의 대비가 이 디자인의 핵심 정체성입니다. 토큰을 임의로 밝혀서 평평하게 만들지 마세요.
4. **별표 UX**: 별표는 "고정되지 않은 상태에선 보이지 않고, 호버 시에만 나타나며, 고정된 카드에선 항상 노란색으로 보이는" 3-state 인터랙션이 중요합니다.
